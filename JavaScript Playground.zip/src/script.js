console.log("Hello world");

var items=["りんご","ゴリラ","ラッパ"];
console.log(items)

for(var i=0; i<items.length; i++){
  console.log(items[i])
}

let sum=0;
for(let i=1; i<=100;i++){
  sum+=i;
}
console.log(sum);
